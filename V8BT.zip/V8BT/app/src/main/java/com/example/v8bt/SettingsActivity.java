package com.example.v8bt;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;


public class SettingsActivity extends AppCompatActivity {


    // constant

    private TextView lblNameGrandparent;
    private TextView lblBirthday;
    private TextView lblWeight;
    private TextView lblHight;
    private TextView lblPhoneGranny;

    private Button btnEditGrandparent;
    private Button btnSaveIt;

    private TextView lblContactsName;
    private TextView lblContactsEmail;
    private TextView lblContactsPhone;

    private Switch switchRingtone;

    // constants for shared Preferences

    public static final String Shared_PREFS = "sharedRefs";
    public static final String Name_Granny = "nameGranny";
    public static final String Birthday_Granny = "birthdayGranny";
    public static final String Weight_Granny = "weightGranny";
    public static final String Hight_Granny = "hightGranny";
    private static final String Granny_Phone = "phoneGranny";

    public static final String SWITCH_RINGTONE = "switchRingtone";

    public static final String Contact_Name = "contactName";
    public static final String Contact_Email = "contactEmail";
    public static final String Contact_Phone = "contactPhone";

    private String GrannyName;
    private String BirthdayGranny;
    private String WeightGranny;
    private String HightGranny;



    public String PhoneGranny;

    private Boolean RingtoneOnOff;

    private String ContactName;
    private String ContactEmail;
    public String ContactPhone;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Link widgets
        lblNameGrandparent = findViewById(R.id.lblGrannyNameSave);
        lblBirthday = findViewById(R.id.lblGrannyBirthdaySave);
        lblWeight = findViewById(R.id.lblGrannyWeightSave);
        lblHight = findViewById(R.id.lblGrannyHightSave);
        lblPhoneGranny = findViewById(R.id.lblGrannyPhoneSave);


        btnEditGrandparent = findViewById(R.id.btnEditGranny);
        btnSaveIt = findViewById(R.id.btnSaveIt);
        Button btnAddContact = findViewById(R.id.btnAddContact);
        switchRingtone =findViewById(R.id.switchRingtone);

        lblContactsName =findViewById(R.id.lblContactNameSave);
        lblContactsEmail = findViewById(R.id.lblcontactEmailSave);
        lblContactsPhone = findViewById(R.id.lblContactPhoneSave);


        // pop-up to fill out the information about the grandparent
        btnAddContact.setOnClickListener(new View.OnClickListener() {
                                             @Override
                                             public void onClick(View v) {
                                                 // create new dialog builder
                                                 AlertDialog.Builder builder = new AlertDialog.Builder(SettingsActivity.this);

                                                 // configure button
                                                 builder.setView(R.layout.contact_information);

                                                 // the information in the crated pop-up will be filled in to the text fields in the Activity
                                                 builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                                                     @Override
                                                     public void onClick(DialogInterface dialog, int which) {
                                                         AlertDialog alertDialog = (AlertDialog) dialog;

                                                         TextView txtContactName = alertDialog.findViewById(R.id.txtContactsNameEdit);
                                                         TextView txtContactEmail = alertDialog.findViewById(R.id.txtEmailEdit);
                                                         TextView txtContactPhone = alertDialog.findViewById(R.id.txtContactPhoneEdit);

                                                         lblContactsName.setText((txtContactName.getText().toString()));
                                                         lblContactsEmail.setText(txtContactEmail.getText().toString());
                                                         lblContactsPhone.setText(txtContactPhone.getText().toString());
                                                     }
                                                 });
                                                 builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                                     @Override
                                                     public void onClick(DialogInterface dialog, int which) {

                                                     }
                                                 });
                                                 // build actual dialog
                                                 AlertDialog dialog = builder.create();

                                                 // show the dialog to the user
                                                 dialog.show();
                                             }
                                         });





        btnEditGrandparent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                    // create new dialog builder
                    AlertDialog.Builder builder = new AlertDialog.Builder(SettingsActivity.this);


                    // configure button
                    builder.setView(R.layout.granny_info);
                // the information in the crated pop-up will be filled in to the text fields in the Activity
                builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        AlertDialog alertDialog = (AlertDialog) dialog;


                        TextView txtNameGrandparentEdit = alertDialog.findViewById(R.id.txtGrandparentsNameEdit);

                                TextView txtBirthdayEdit= alertDialog.findViewById(R.id.txtBirthdayEdit);
                                TextView txtWeightEdit = alertDialog.findViewById(R.id.txtWeightEdit);
                                TextView txtHightEdit = alertDialog.findViewById(R.id.txtHightEdit);
                                TextView txtPhoneGrannyEdit = alertDialog.findViewById(R.id.txtPhoneEdit);

                                lblNameGrandparent.setText(txtNameGrandparentEdit.getText().toString());
                                lblBirthday.setText(txtBirthdayEdit.getText().toString());
                                lblHight.setText(txtHightEdit.getText().toString());
                                lblWeight.setText(txtWeightEdit.getText().toString());
                                lblPhoneGranny.setText(txtPhoneGrannyEdit.getText().toString());
                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                });

                    // build actual dialog
                    AlertDialog dialog = builder.create();

                    // show the dialog to the user
                    dialog.show();
            }
            });
        btnSaveIt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveData();
                //setPhoneGranny(PhoneGranny);
                Intent Main = new Intent(SettingsActivity.this, MainActivity.class);
                Main.putExtra("GrannysPhonenumber", PhoneGranny);
                startActivity(Main);
            }
        });
        loadData();
        updateViews();
    }

    // old try to save data for other Activities
    /*
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("GrannyPhoneNumber",PhoneGranny);}
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        // get values from saved state
        //PHONEGRANNYSTAT=savedInstanceState.getString("GrannyPhoneNumber");
        super.onRestoreInstanceState(savedInstanceState);
    }

     */
    // save data in shared preferences
    public void saveData(){
        SharedPreferences sharedPreferences = getSharedPreferences(Shared_PREFS,MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(Name_Granny, lblNameGrandparent.getText().toString());
        editor.putString(Birthday_Granny,lblBirthday.getText().toString());
        editor.putString(Weight_Granny, lblWeight.getText().toString());
        editor.putString(Hight_Granny,lblHight.getText().toString());
        editor.putString(Granny_Phone,lblPhoneGranny.getText().toString());

        editor.putBoolean(SWITCH_RINGTONE,switchRingtone.isChecked());

        editor.putString(Contact_Name,lblContactsName.getText().toString());
        editor.putString(Contact_Email,lblContactsEmail.getText().toString());
        editor.putString(Contact_Phone,lblContactsPhone.getText().toString());

        editor.apply();

        Toast.makeText(this, "data saved", Toast.LENGTH_SHORT).show();
    }
    // load data from shared preferences
    public void loadData(){
        SharedPreferences sharedPreferences =getSharedPreferences(Shared_PREFS,MODE_PRIVATE);
        GrannyName = sharedPreferences.getString(Name_Granny,"");
        BirthdayGranny = sharedPreferences.getString(Birthday_Granny,"");
        WeightGranny = sharedPreferences.getString(Weight_Granny,"");
        HightGranny = sharedPreferences.getString(Hight_Granny,"");
        PhoneGranny = sharedPreferences.getString(Granny_Phone,"");

        RingtoneOnOff = sharedPreferences.getBoolean(SWITCH_RINGTONE,false);

        ContactName = sharedPreferences.getString(Contact_Name,"");
        ContactEmail = sharedPreferences.getString(Contact_Email,"");
        ContactPhone = sharedPreferences.getString(Contact_Phone,"");

    }
    //show loaded data in View again
    public void updateViews(){
        lblNameGrandparent.setText(GrannyName);
        lblBirthday.setText(BirthdayGranny);
        lblWeight.setText(WeightGranny);
        lblHight.setText(HightGranny);
        lblPhoneGranny.setText(PhoneGranny);

        switchRingtone.setChecked(RingtoneOnOff);

        lblContactsName.setText(ContactName);
        lblContactsEmail.setText(ContactEmail);
        lblContactsPhone.setText(ContactPhone);
    }
    /*old try to transfer data from one activity to an other
    public static String getPhoneGranny() {
        return PHONEGRANNYSTAT;
    }

    public void setPhoneGranny(String phoneGranny) {
        PHONEGRANNYSTAT = phoneGranny;
    }

     */
    /*
    public void setContactPhone(String contact){
        this.ContactPhone =contact;
    }
    public void setGrannyPhone(String granny){
        this.PhoneGranny=granny;
    }
    public String getContactPhone(){
        return ContactPhone;
    }
    public String getGrannyPhone(){
        return PhoneGranny;
    }

     */
}