package com.example.v8bt;


public class ChatMessage {
    private final String user;
    private final long timestamp;
    private final String message;

    public ChatMessage(String user, long timestamp, String message) {
        this.user = user;
        this.timestamp = timestamp;
        this.message = message;
    }

    public String getUser() {
        return user;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public String getMessage() {
        return message;
    }
}
