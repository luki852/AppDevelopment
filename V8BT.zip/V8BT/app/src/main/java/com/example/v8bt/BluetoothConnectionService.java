package com.example.v8bt;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class BluetoothConnectionService {
    private static final String TAG = "MyBluetoothConnectionService";


    private static final String appName = "V6BT_BT_Communication";

    //private static final UUID MY_UUID_INSECURE = UUID.fromString("8ce255c0-200a-11e0-ac64-0800200c9a66");
    private static final UUID MY_UUID_INSECURE = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private final BluetoothAdapter mBluetoothAdapter;
    Context mContext;

    private AcceptThread mInsecureAcceptThread;

    private ConnectThread mConnectThread;
    private BluetoothDevice mDevice;
    private UUID deviceUUID;
    ProgressDialog mProgressDialog;

    private ConnectedThread mConnectedThread;

    String incomingMessage;

    public BluetoothConnectionService(Context context) throws IOException {
        mContext = context;
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        //MainActivity main = new MainActivity();
        Log.d(TAG, "BT Service Constructor was called.");
        //main.showToast("BT Service Constructor.");
        start();
    }

    private class AcceptThread extends Thread {
        private final BluetoothServerSocket mServerSocket;

        public AcceptThread() throws IOException {
            BluetoothServerSocket tmp = null;
            try {
                tmp = mBluetoothAdapter.listenUsingInsecureRfcommWithServiceRecord(appName, MY_UUID_INSECURE);
                Log.d(TAG, "Setting up Server using: " + MY_UUID_INSECURE);
            }catch (IOException e) {
                Log.e(TAG, "IOException starting server socket: " + e.getMessage());
            }
            mServerSocket = tmp;
        }

        public void run() {
            Log.d(TAG, "Accept Thread is running.");

            BluetoothSocket socket = null;
            try {
                socket = mServerSocket.accept();
                Log.d(TAG, "Server socket accepted connection.");
            }catch (IOException e) {
                Log.e(TAG, "IOException accepting connection: " + e.getMessage());
            }

            if(socket != null) {
                Log.d(TAG, "Socket is listening.");
                connected(socket,mDevice);
            }
        }

        public void cancel() {
            Log.d(TAG, "Canceling Accept Thread");
            try {
                mServerSocket.close();
            }catch (IOException e){
                Log.e(TAG, "IOException cancelling accept thread: " + e.getMessage());
            }
        }
    }

    private class ConnectThread extends Thread {
        public BluetoothSocket mSocket;

        public ConnectThread (BluetoothDevice device, UUID uuid) {
            Log.d(TAG, "Start connect thread");
            mDevice = device;
            deviceUUID = uuid;

            mBluetoothAdapter.cancelDiscovery();
        }

        public void run() {
            BluetoothSocket tmp = null;
            try {
                tmp = mDevice.createInsecureRfcommSocketToServiceRecord(deviceUUID);
            }catch(IOException e){
                Log.e(TAG, "IOException starting connect thread: " + e.getMessage());
            }
            mSocket = tmp;
            try {
                mSocket.connect();
                Log.d(TAG, "Successfully connected");
            } catch (IOException e) {
                Log.e(TAG, "IOException connecting to socket in connect thread: " + e.getMessage());
                try {
                    mSocket.close();
                } catch (IOException ioException) {
                    Log.e(TAG, "IOException closing socket in connect thread: " + ioException.getMessage());
                }
                Log.d(TAG, "Could not connect to UUID: " + MY_UUID_INSECURE);
            }

            connected(mSocket, mDevice);
        }

        public void cancel() {
            Log.d(TAG, "Canceling Accept Thread");
            try {
                mSocket.close();
            }catch (IOException e){
                Log.e(TAG, "IOException cancelling accept thread: " + e.getMessage());
            }
        }
    }

    public synchronized void start() throws IOException {
        Log.d(TAG,"start");

        if(mConnectThread != null) {
            mConnectThread.cancel();
            mConnectThread = null;
        }
        if(mInsecureAcceptThread == null) {
            mInsecureAcceptThread = new AcceptThread();
            mInsecureAcceptThread.start();
        }
    }

    public void startClient(BluetoothDevice device, UUID uuid) {
        Log.d(TAG,"start Client");
        mProgressDialog = ProgressDialog.show(mContext, "Connecting Bluetooth", "Please Wait ...", true);

        mConnectThread = new ConnectThread(device, uuid);
        mConnectThread.start();
    }

    private class ConnectedThread extends Thread {
        private final BluetoothSocket mSocket;
        private final InputStream mInStream;
        private final OutputStream mOutStream;

        public ConnectedThread(BluetoothSocket socket) {
            Log.d(TAG, "Start connected thread");

            mSocket = socket;
            InputStream tmpIn = null;
            OutputStream tmpOut = null;

            mProgressDialog.dismiss();

            try {
                tmpIn = mSocket.getInputStream();
                tmpOut = mSocket.getOutputStream();
            }catch (IOException e){
                Log.e(TAG, "IOException getting In- and Output Stream: " + e.getMessage());
            }
            mInStream = tmpIn;
            mOutStream = tmpOut;
        }

        public void run () {
            byte[] buffer = new byte[1024];
            int bytes;
            String myMsg = "Mir Wurst!";
            byte[] msg = myMsg.getBytes(StandardCharsets.UTF_8);
            while(true) {
                try {
                    bytes = mInStream.read(buffer);
                    incomingMessage = new String(buffer, 0,bytes);
                    Log.d(TAG, "Message: " + incomingMessage);
// changing activity when a bluetooth message arrives
                    Intent AlertIntent = new Intent(mContext, AlertActivity.class);
                    //AlertIntent.putExtra("GrannyPhone",MainActivity.PhoneGranny);
                    mContext.startActivity(AlertIntent);




                } catch (IOException e) {
                    Log.e(TAG, "IOException reading InputStream: " + e.getMessage());
                    break;
                }
            }
        }

        public void write(byte[] bytes) {
            String text = new String(bytes, Charset.defaultCharset());
            Log.d(TAG,"Writing in OutputStream: "+ text);
            try{
                mOutStream.write(bytes);
            }catch (IOException e) {
                Log.e(TAG, "IOException writing OutputStream: " + e.getMessage());
            }
        }

        public void cancel() {
            Log.d(TAG, "Canceling Accept Thread");
            try {
                mSocket.close();
            }catch (IOException e){
                Log.e(TAG, "IOException cancelling accept thread: " + e.getMessage());
            }
        }
    }

    private void connected(BluetoothSocket socket, BluetoothDevice mDevice) {
        Log.d(TAG,"Start connected method.");

        mConnectedThread = new ConnectedThread(socket);
        mConnectedThread.start();
    }

    public void write(byte[] out) {
        ConnectedThread r;
        mConnectedThread.write(out);
    }

}
