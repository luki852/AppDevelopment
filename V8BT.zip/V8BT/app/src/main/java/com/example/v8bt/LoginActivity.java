package com.example.v8bt;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    // Properties of Login screen

    private Button btnLogin;
    private TextView txtName;
    private TextView txtPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Link widgets
        btnLogin = findViewById(R.id.btnLogin);
        txtName = findViewById(R.id.txtName);
        txtPassword = findViewById(R.id.txtPassword);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Login();

            }
        });

    }
    // compares Username and password with the Text fields txtName and txtPassword
    private void Login() {
        if (txtName.getText().toString().equals("Granny") && txtPassword.getText().toString().equals("Schoki")) {

            //correct password and Username
            String welcome = "Welcome to our App!";
            Toast.makeText(getApplicationContext(), welcome, Toast.LENGTH_LONG).show();

            // Start MainActivity
            launchMain();


        } else if (txtName.getText().toString().equals("Relatives") && txtPassword.getText().toString().equals("Care2Much")) {

            //correct password and Username
            String welcome = "Welcome!";
            Toast.makeText(getApplicationContext(), welcome, Toast.LENGTH_LONG).show();

            // Start MainActivity
            launchMain();


        } else {
            //wrong password
            String wrong = "Wrong Password!";
            Toast.makeText(getApplicationContext(), wrong, Toast.LENGTH_LONG).show();
        }
    }
    // start Intent to load MainActivity
    private void launchMain() {
        Intent mainIntent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(mainIntent);
    }
}