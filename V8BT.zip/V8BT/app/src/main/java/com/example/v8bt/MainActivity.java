package com.example.v8bt;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity { //implements AdapterView.OnItemClickListener {

    //define constants for Bluetooth
    String tag = "MyBLUETOOTH";
    String deviceName = "HIProtect";
    //String deviceAddress = "08:3A:F2:B9:84:B6";
    String deviceAddress = "24:6F:28:97:47:02";
    private static final UUID MY_UUID_SECURE = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private static final int REQUEST_ENABLE_BT = 1;
    private static final int REQUEST_DISCOVER_BT = 2;
    private static final int PERMISSION_REQUEST_BLUETOOTH_CONNECT = 3;
    private static final int PERMISSION_REQUEST_BLUETOOTH_ADVERTISE = 4;
    private static final int PERMISSION_REQUEST_BLUETOOTH_SCAN = 5;

    BluetoothAdapter myBTAdapter;
    ActivityResultLauncher<Intent> enableBTResultLauncher;
    ActivityResultLauncher<Intent> visibleBTResultLauncher;
    BluetoothConnectionService mBluetoothConnection;
    BluetoothDevice mBTDevice;
    Button btnConnect;
    Button btnSendDefaultMessage;
    // end constants for Bluetooth

    //constants
    private FloatingActionButton btnSettings;
    private String TestMessage;
    private String txtMessageInput = "Airbag has been activated";
    private TextView lblPhoneGranny;

    public String PhoneGranny;
    private  boolean ringtone;


    //region Constants for mqtt
    private static final String MY_USER_NAME = "mqttUser" + UUID.randomUUID().hashCode();
    private static final String chatTopic = "mci_AppProgramming/Project/HiProtect";

    private com.example.v8bt.SimpleMqttClient client;
    //endregion


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // get Grannys PhoneNumber and state of ringtone switch from Settings Activity

        if(getIntent().hasExtra("GrannysPhonenumber")==true){
            PhoneGranny = getIntent().getExtras().getString("GrannysPhonenumber");
        }
        else {
            PhoneGranny = "00000";
        }
        ringtone = getSharedPreferences(SettingsActivity.Shared_PREFS,MODE_PRIVATE).getBoolean("switchRingtone",false);


       /* old try to get Variables
        // get PhoneNumber from Settings Activity
        SettingsActivity Settings = new SettingsActivity();
        PhoneGranny = Settings.getContactPhone();
        PhoneContact = Settings.getGrannyPhone();

         */

        // link
        btnSettings = findViewById(R.id.btnSettings);
        lblPhoneGranny =findViewById(R.id.lblPhoneGrannyMain);
        lblPhoneGranny.setText(PhoneGranny);
        ImageButton btnSend = findViewById(R.id.btnSend);
        btnConnect = findViewById(R.id.btnConnect);
        btnSendDefaultMessage = findViewById(R.id.btnSendDefaultMessage);

        //check if bluetooth is supported
        if(!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH)) {
            Log.d(tag, "Bluetooth is not supported on this device.");
        }
        Log.d(tag, "Create Bluetooth Manager.");
        final BluetoothManager btManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        myBTAdapter = btManager.getAdapter();
        if (myBTAdapter == null) {
            Log.d(tag, "Bluetooth is not available.");
        }
        else {
            Log.d(tag, "Bluetooth is available.");
        }

        enableBTResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if(result.getResultCode() == Activity.RESULT_OK) {
                            Log.d(tag,"Bluetooth is enabled.");
                            //makeDeviceVisible();
                        }
                        else {
                            Log.d(tag,"Enabling Bluetooth failed.");
                        }
                    }
                });

        visibleBTResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if(result.getResultCode() == Activity.RESULT_OK) {
                            Log.d(tag,"Your device is visible.");
                        }
                        else {
                            Log.d(tag,"Making your device visible failed.");
                        }
                    }
                });

        //Pair to device
        IntentFilter pairIntentFilter = new IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        registerReceiver(mBroadcastReceiverPairing, pairIntentFilter);

        // Send mqtt message for testing
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                publishMessage() ;

            }
        });

        // create MQTT client object (not connected yet)
        client = new com.example.v8bt.SimpleMqttClient("broker.hivemq.com", 1883, UUID.randomUUID().toString());
        // changing Activity to Settings Activity
        btnSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent SettingIntent = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(SettingIntent);

            }
        });


        // enable Bluetooth and connecting to the ESP32, the address of the ESP32 is hard coded
        btnConnect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                if(!myBTAdapter.isEnabled()) {
                    showToast("Turning on Bluetooth.");
                    enableBluetooth();
                }
                else {
                    showToast("Bluetooth is already on.");
                }
                startConnection();
            }
        });
        //for testing reasons. sending a default message to the ESP32
        btnSendDefaultMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //byte[] bytes = txtMessage.getText().toString().getBytes(Charset.defaultCharset());
                String defaultMsg = "Mir Wurst!";
                byte[] bytes = defaultMsg.getBytes(StandardCharsets.UTF_8);
                mBluetoothConnection.write(bytes);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        // !!NOTE!! too early to connect if we use UI elements to communicate success/failure (no UI yet)
        //if(client.isConnected()) {
        //    connectAndSubscribe();
        //}
    }

    @Override
    protected void onResume() {
        super.onResume();
        // at this point the UI is available
        if(!client.isConnected()) {
            // only proceed if we are not connected already
            connect();
            subscribe(chatTopic);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        // unsubscribe and disconnect when stopping the activity
        client.unsubscribe(chatTopic);
        client.disconnect();
    }
    //endregion

    //region JSON serialization/deserialization
    private ChatMessage deserializeMessage(String json) throws JSONException {
        JSONObject jMessage = new JSONObject(json);

        String sUser = jMessage.getString("user");
        long sTimestamp = jMessage.getLong("timestamp");
        String sBody = jMessage.getString("body");

        ChatMessage newMsg = new ChatMessage(sUser, sTimestamp, sBody);

        return newMsg;
    }

    private String serializeMessage(ChatMessage msg) throws JSONException {
        JSONObject jMessage = new JSONObject(); // {}

        jMessage.put("user", msg.getUser()); // {"user":"username"}
        jMessage.put("timestamp", msg.getTimestamp()); // {"user":"username","timestamp", 1341234}
        jMessage.put("body", msg.getMessage()); // {"user":"username","timestamp":1341234,"body":"Message"}

        return jMessage.toString();
    }
    //endregion

    //region MQTT related methods
    private void connect() {
        // establish connection to server (asynchronous)
        client.connect(new com.example.v8bt.SimpleMqttClient.MqttConnection(this) {
            @Override
            public void onSuccess() {
                Toast.makeText(MainActivity.this, "Connection successful", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(Throwable error) {
                showError("Unable to connect");
            }
        });
    }

    private void subscribe(String topic) {
        // subscribe to chatTopic (asynchronous)
        client.subscribe(new com.example.v8bt.SimpleMqttClient.MqttSubscription(this, chatTopic) {
            @Override
            public void onMessage(String topic, String payload) {
                // new message arrived

                // deserialize JSOn into ChatMessage object
                try {
                    ChatMessage msg = deserializeMessage(payload);

                    // ringtone will be set if the Switch is true in the settings Activity
                    if(ringtone==true) {
                        Uri alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);

                        if (alert == null) {
                            alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                            if (alert == null) {
                                alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
                            }
                        }
                        Ringtone ringtone = RingtoneManager.getRingtone(MainActivity.this, alert);
                        ringtone.play();
                    }


                    // an Pop up will be created, if a mqtt message arrives
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    builder.setCancelable(true);
                    builder.setTitle("Alert");
                    builder.setMessage("airbag has been activated");
                    builder.setPositiveButton("Call",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    // The phone number of the granny, which is stored in the Settings activity will be prefilled
                                    Intent call = new Intent(Intent.ACTION_DIAL);
                                    call.setData(Uri.parse("tel:" + PhoneGranny));
                                    startActivity(call);
                                }



                            });
                    builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });

                    AlertDialog dialog = builder.create();
                    dialog.show();


                    //listAdapter.add(msg);
                } catch(JSONException je) {
                    Log.e("JSON", "Error while deserializing payload", je);
                    showError("Invalid chat message received");
                }
            }

            @Override
            public void onError(Throwable error) {
                showError("Unable to join chat");
            }
        });
    }

    public void publishMessage() {
        // create new ChatMessage object from parameters
        ChatMessage msg = new ChatMessage(MY_USER_NAME, LocalDateTime.now().toEpochSecond(ZoneOffset.UTC), txtMessageInput);

        //serialize message before sending
        try {
            String jsonMessage = serializeMessage(msg);

            //publish to topic
            client.publish(new com.example.v8bt.SimpleMqttClient.MqttPublish(this, chatTopic, jsonMessage) {
                @Override
                public void onError(Throwable error) {
                    showError("Unable to send");
                }
            });
        } catch (JSONException je) {
            Log.e("JSON", "Error while serializing message", je);
            showError("Unable to send");
        }
    }


    // Show Toast on error
    private void showError(String msg) {
        Toast.makeText(this, String.format("Unexpected error: %s. Check the log for details", msg), Toast.LENGTH_LONG).show();
    }
    //endregion

    /********************************************************************************************
     * Function to enable Bluetooth on mobile device
     ********************************************************************************************/
    public void enableBluetooth() {
        Log.d(tag, "Bluetooth is available. Check permissions");

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH) != PackageManager.PERMISSION_GRANTED) {
            Log.d(tag, "No Bluetooth Permission to enable Bluetooth. Request permission. NOT DONE YET");
        }
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADMIN) != PackageManager.PERMISSION_GRANTED) {
            Log.d(tag, "No Admin Bluetooth Permission to enable Bluetooth. Request permission. NOT DONE YET");
        }

        else {
            Log.d(tag, "Permissions are enabled. Check if Bluetooth is enabled.");
            if(myBTAdapter.isEnabled()) {
                Log.d(tag,"Bluetooth is already enabled.");
            }
            else {
                Log.d(tag,"Try to enable Bluetooth.");
                myBTAdapter.enable();
                Intent enableBTIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);


                Log.d(tag,"Launch enable bluetooth intent.");
                enableBTResultLauncher.launch(enableBTIntent);

                Log.d(tag,"Register Receiver for enabling bluetooth.");
                IntentFilter BTIntentFilter = new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED);
                registerReceiver(mBroadcastReceiverEnableBT, BTIntentFilter);
            }
        }
    }

    /********************************************************************************************
     * Function to disable bluetooth
     ********************************************************************************************/
    public void disableBluetooth() {
        if(!myBTAdapter.isEnabled()) {
            Log.d(tag,"Bluetooth is already off.");
        }
        else {
            Log.d(tag,"Disabling Bluetooth.");
            myBTAdapter.disable();
        }
    }

    /********************************************************************************************
     * Function to make bluetooth device visible/discoverable
     ********************************************************************************************/
    public void makeDeviceVisible() {
        //make yourself visible
        Log.d(tag,"Making your device discoverable.");
        Intent discoverableIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
        visibleBTResultLauncher.launch(discoverableIntent);

        IntentFilter visibilityIntentFilter = new IntentFilter(BluetoothAdapter.ACTION_SCAN_MODE_CHANGED);
        registerReceiver(mBroadcastReceiverEnableVisibility, visibilityIntentFilter);

    }

    /********************************************************************************************
     * Function to discover bluetooth devices
     ********************************************************************************************/
    public void discoverBluetoothDevices() {
        Log.d(tag, "Start discovering Bluetooth devices.");
        if(myBTAdapter.isDiscovering()) {
            myBTAdapter.cancelDiscovery();
            Log.d(tag, "Discovering process was canceled.");
        }

        myBTAdapter.startDiscovery();
        IntentFilter discoverDeviceIntent = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(mBroadcastReceiverDiscover, discoverDeviceIntent);
    }

    /********************************************************************************************
     * Function to start Connection to ESP32
     ********************************************************************************************/
    public void startConnection() {
        myBTAdapter.cancelDiscovery();
        Log.d(tag, "Discovery process was canceled.");

        Log.d(tag, "Bonding to: " + deviceName + " with address: " + deviceAddress);
        try {
            mBluetoothConnection = new BluetoothConnectionService(MainActivity.this);
            //mBluetoothConnection = new BluetoothChatService(activity, mHandler);
        } catch (IOException e) {
            Log.e(tag, "IOException initializing connection process: " + e.getMessage());
        }

        //Init mBTDevice
        mBTDevice = myBTAdapter.getRemoteDevice(deviceAddress);

        mBluetoothConnection.startClient(mBTDevice, MY_UUID_SECURE);
    }

    /********************************************************************************************
     * Callback of permission request
     ********************************************************************************************/
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        Log.d(tag,"Callback for permission request.");

        //Permission Connect Bluetooth
        if (requestCode == PERMISSION_REQUEST_BLUETOOTH_CONNECT) {
            Log.d(tag,"Callback for connect bluetooth.");
            if(grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //Permission has been granted, call again enableBluetooth();
                Log.d(tag,"Permission to enable connect bluetooth has been granted.");
                enableBluetooth();
            }
            else {
                //Permission has been denied
                Log.d(tag,"Permission to enable connect bluetooth has been denied.");
                enableBluetooth();
            }
        }

        //Permission Advertise Bluetooth
        if (requestCode == PERMISSION_REQUEST_BLUETOOTH_ADVERTISE) {
            Log.d(tag,"Callback for advertise bluetooth.");
            if(grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //Permission has been granted, call again enableBluetooth();
                Log.d(tag,"Permission to enable advertise bluetooth has been granted.");
                enableBluetooth();
            }
            else {
                //Permission has been denied
                Log.d(tag,"Permission to enable advertise bluetooth has been denied.");
                enableBluetooth();
            }
        }

        //Permission Scan Bluetooth
        if (requestCode == PERMISSION_REQUEST_BLUETOOTH_SCAN) {
            Log.d(tag,"Callback for scan bluetooth.");
            if(grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //Permission has been granted, call again enableBluetooth();
                Log.d(tag,"Permission to enable scan bluetooth has been granted.");
                enableBluetooth();
            }
            else {
                //Permission has been denied
                Log.d(tag,"Permission to enable scan bluetooth has been denied.");
                enableBluetooth();
            }
        }

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    /********************************************************************************************
     * Callback for startActivityForResult()
     ********************************************************************************************/
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == REQUEST_ENABLE_BT) {
            Log.d(tag,"Callback onActivityResult of REQUEST_ENABLE_BT.");
            if (resultCode == RESULT_OK) {
                showToast("Bluetooth is on.");
                Log.d(tag,"Bluetooth is on.");
            }
            else if (resultCode == RESULT_CANCELED) {
                showToast("Could not turn on Bluetooth.");
                Log.d(tag,"Could not turn on Bluetooth.");
            }
        }
        else if (requestCode == REQUEST_DISCOVER_BT) {
            Log.d(tag,"Callback onActivityResult of REQUEST_DISCOVER_BT.");
            if (resultCode == RESULT_OK) {
                showToast("Device is visible.");
                Log.d(tag,"Device is visible.");
            }
            else if (resultCode == RESULT_CANCELED) {
                showToast("Could not make device visible.");
                Log.d(tag,"Could not make device visible.");
            }
        }

        super.onActivityResult(requestCode, resultCode, data);
    }

    /********************************************************************************************
     * Create a Broadcast Receiver for Enable/Disable Bluetooth
     ********************************************************************************************/
    private final BroadcastReceiver mBroadcastReceiverEnableBT = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            Log.d(tag, "Receiver for enabling bluetooth was called");
            String action = intent.getAction();
            if (action.equals(myBTAdapter.ACTION_STATE_CHANGED)) {
                final int state = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR);
                switch(state){
                    case BluetoothAdapter.STATE_OFF:
                        Log.d(tag, "mBroadcastReceiverEnableBT: STATE OFF");
                        break;
                    case BluetoothAdapter.STATE_TURNING_OFF:
                        Log.d(tag, "mBroadcastReceiverEnableBT: STATE_TURNING_OFF");
                        break;
                    case BluetoothAdapter.STATE_ON:
                        Log.d(tag, "mBroadcastReceiverEnableBT: STATE_ON");
                        break;
                    case BluetoothAdapter.STATE_TURNING_ON:
                        Log.d(tag, "mBroadcastReceiverEnableBT: STATE_TURNING_ON");
                        break;
                }
            }
        }
    };

    /********************************************************************************************
     * Create a Broadcast Receiver for visibility
     ********************************************************************************************/
    private final BroadcastReceiver mBroadcastReceiverEnableVisibility = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            Log.d(tag, "Receiver for visibility was called");
            String action = intent.getAction();
            if (action.equals(myBTAdapter.ACTION_SCAN_MODE_CHANGED)) {
                final int mode = intent.getIntExtra(BluetoothAdapter.EXTRA_SCAN_MODE, BluetoothAdapter.ERROR);
                switch(mode){
                    case BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE:
                        Log.d(tag, "mBroadcastReceiverEnableVisibility: Discoverability is enabled");
                        break;
                    case BluetoothAdapter.SCAN_MODE_CONNECTABLE:
                        Log.d(tag, "mBroadcastReceiverEnableVisibility: Discoverability is disabled. Able to receive connections.");
                        break;
                    case BluetoothAdapter.SCAN_MODE_NONE:
                        Log.d(tag, "mBroadcastReceiverEnableVisibility: Discoverability is disabled. Not able to receive connections");
                        break;
                    case BluetoothAdapter.STATE_CONNECTING:
                        Log.d(tag, "mBroadcastReceiverEnableVisibility: Connecting...");
                        break;
                    case BluetoothAdapter.STATE_CONNECTED:
                        Log.d(tag, "mBroadcastReceiverEnableVisibility: Connected.");
                        break;
                }
            }
        }
    };

    /********************************************************************************************
     * Create a Broadcast Receiver for Discover Process
     ********************************************************************************************/
    private BroadcastReceiver mBroadcastReceiverDiscover = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            Log.d(tag, "Receiver for discovery process was called.");
            final String action = intent.getAction();
            if (action.equals(BluetoothDevice.ACTION_FOUND)) {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                Log.d(tag, device.getName() + " : " + device.getAddress());
            }
        }
    };

    /********************************************************************************************
     * Create a Broadcast Receiver for Pairing Process
     ********************************************************************************************/
    private BroadcastReceiver mBroadcastReceiverPairing = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            Log.d(tag, "Receiver for pairing process was called.");

            if(action.equals(BluetoothDevice.ACTION_BOND_STATE_CHANGED)) {
                BluetoothDevice mDevice = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if(mDevice.getBondState() == BluetoothDevice.BOND_BONDED) {
                    Log.d(tag, "mBroadcastReceiverPairing: BOND_BONDED.");
                    mBTDevice = mDevice;
                }
                if(mDevice.getBondState() == BluetoothDevice.BOND_BONDING) {
                    Log.d(tag, "mBroadcastReceiverPairing: BOND_BONDING.");
                }
                if(mDevice.getBondState() == BluetoothDevice.BOND_NONE) {
                    Log.d(tag, "mBroadcastReceiverPairing: BOND_BONDING.");
                }
            }
        }
    };

    /********************************************************************************************
     * Function to clean up
     ********************************************************************************************/
    protected void onDestroy() {
        Log.d(tag, "onDestroy called");
        super.onDestroy();
        unregisterReceiver(mBroadcastReceiverEnableBT);
        unregisterReceiver(mBroadcastReceiverEnableVisibility);
        unregisterReceiver(mBroadcastReceiverDiscover);
        unregisterReceiver(mBroadcastReceiverPairing);
    }

    /********************************************************************************************
     * Function to show text as short pop up
     ********************************************************************************************/
    public void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
