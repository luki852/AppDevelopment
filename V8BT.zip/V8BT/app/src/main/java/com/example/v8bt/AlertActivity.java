package com.example.v8bt;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDateTime;
import java.time.ZoneOffset;


public class AlertActivity extends AppCompatActivity {
    // constants
    Button btnCancel;
    Button btnCall;

    private String PhoneContact;
    private Boolean ringtone;
    private String MessageInput;
    //mqtt
    private com.example.v8bt.SimpleMqttClient client;
    private static final String MY_USER_NAME = "mqttUser" + UUID.randomUUID().hashCode();
    private static final String chatTopic = "mci_AppProgramming/Project/HiProtect";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alert);

        // get Variables from SettingsActivity
        PhoneContact = getSharedPreferences(SettingsActivity.Shared_PREFS,MODE_PRIVATE).getString("contactPhone","00000");
        ringtone = getSharedPreferences(SettingsActivity.Shared_PREFS,MODE_PRIVATE).getBoolean("switchRingtone",false);


        //link
        btnCancel = findViewById(R.id.btnSkip);
        btnCall = findViewById(R.id.btnCall);

        MessageInput = "Airbag has been inflated";

        client = new com.example.v8bt.SimpleMqttClient("broker.hivemq.com", 1883, UUID.randomUUID().toString());

        // a mqtt massage will be send as soon as the Activity has started
        if(client.isConnected()) {
            publishMessage(chatTopic, MessageInput);
        }

        // button to go back to the Main Activity
        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goToMain = new Intent(AlertActivity.this,MainActivity.class);
                startActivity(goToMain);
            }
        });
        //button to prefill the phone number of the contact, which is stored in settingsActivity
        btnCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                Intent call = new Intent(Intent.ACTION_DIAL);
                call.setData(Uri.parse("tel:"+  PhoneContact));
                startActivity(call);


            }
        });




    }
    @Override
    protected void onStart() {
        super.onStart();

        // !!NOTE!! too early to connect if we use UI elements to communicate success/failure (no UI yet)
        //if(client.isConnected()) {
        //    connectAndSubscribe();
        //}

    }
    /*
    old try to get Variables from an other Activity
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        // get values from saved state
        PHONEGRANNYSTAT=savedInstanceState.getString("GrannyPhoneNumber");
        super.onRestoreInstanceState(savedInstanceState);
    }

     */

    @Override
    protected void onResume() {
        super.onResume();
        // at this point the UI is available
        if(!client.isConnected()) {
            // only proceed if we are not connected already
            connect();
            subscribe(chatTopic);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();

        // unsubscribe and disconnect when stopping the activity
        client.unsubscribe(chatTopic);
        client.disconnect();
    }
    //endregion

    //region JSON serialization/deserialization
    private ChatMessage deserializeMessage(String json) throws JSONException{
        JSONObject jMessage = new JSONObject(json);

        String sUser = jMessage.getString("user");
        long sTimestamp = jMessage.getLong("timestamp");
        String sBody = jMessage.getString("body");

        ChatMessage newMsg = new ChatMessage(sUser, sTimestamp, sBody);

        return newMsg;
    }

    private String serializeMessage(ChatMessage msg) throws JSONException {
        JSONObject jMessage = new JSONObject(); // {}

        jMessage.put("user", msg.getUser()); // {"user":"username"}
        jMessage.put("timestamp", msg.getTimestamp()); // {"user":"username","timestamp", 1341234}
        jMessage.put("body", msg.getMessage()); // {"user":"username","timestamp":1341234,"body":"Message"}

        return jMessage.toString();
    }
    //endregion

    //region MQTT related methods
    private void connect() {
        // establish connection to server (asynchronous)
        client.connect(new com.example.v8bt.SimpleMqttClient.MqttConnection(this) {
            @Override
            public void onSuccess() {
                Toast.makeText(AlertActivity.this, "Connection successful", Toast.LENGTH_SHORT).show();
            publishMessage(chatTopic,MessageInput);
            }

            @Override
            public void onError(Throwable error) {
                showError("Unable to connect");
            }
        });
    }

    private void subscribe(String topic) {
        // subscribe to chatTopic (asynchronous)
        client.subscribe(new com.example.v8bt.SimpleMqttClient.MqttSubscription(this, chatTopic) {
            @Override
            public void onMessage(String topic, String payload) {
                // new message arrived

                // deserialize JSOn into ChatMessage object
                try {
                    ChatMessage msg = deserializeMessage(payload);
                    // ringtone will be set if the Switch is true in the settings Activity
                    if(ringtone==true) {
                        Uri alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);

                        if (alert == null) {
                            alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
                            if (alert == null) {
                                alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
                            }
                        }
                        Ringtone ringtone = RingtoneManager.getRingtone(AlertActivity.this, alert);
                        ringtone.play();
                    }

                    // // an Pop up will be created, if a mqtt message arrives
                    AlertDialog.Builder builder = new AlertDialog.Builder(AlertActivity.this);
                    builder.setCancelable(true);
                    builder.setTitle("Alert");
                    builder.setMessage("airbag has been activated");
                    builder.setPositiveButton("Call",
                            new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    // The phone number of the contact, which is stored in the Settings activity will be prefilled
                                    Intent call = new Intent(Intent.ACTION_DIAL);
                                    call.setData(Uri.parse("tel:" + PhoneContact));
                                    startActivity(call);
                                }
                            });

                    builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });

                    AlertDialog dialog = builder.create();
                    dialog.show();

                } catch(JSONException je) {
                    Log.e("JSON", "Error while deserializing payload", je);
                    showError("Invalid chat message received");
                }
            }

            @Override
            public void onError(Throwable error) {
                showError("Unable to join chat");
            }
        });
    }

    private void publishMessage(String topic, String body) {
        // create new ChatMessage object from parameters
        ChatMessage msg = new ChatMessage(MY_USER_NAME, LocalDateTime.now().toEpochSecond(ZoneOffset.UTC), body);

        //serialize message before sending
        try {
            String jsonMessage = serializeMessage(msg);

            //publish to topic
            client.publish(new com.example.v8bt.SimpleMqttClient.MqttPublish(this, topic, jsonMessage) {
                @Override
                public void onError(Throwable error) {
                    showError("Unable to send");
                }
            });
        } catch (JSONException je) {
            Log.e("JSON", "Error while serializing message", je);
            showError("Unable to send");
        }
    }

    // Show Toast on error
    private void showError(String msg) {
        Toast.makeText(this, String.format("Unexpected error: %s. Check the log for details", msg), Toast.LENGTH_LONG).show();
    }
    //endregion
}